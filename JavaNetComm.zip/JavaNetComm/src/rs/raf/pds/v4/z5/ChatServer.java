package rs.raf.pds.v4.z5;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import com.esotericsoftware.kryonet.Connection;
import com.esotericsoftware.kryonet.Listener;
import com.esotericsoftware.kryonet.Server;

import rs.raf.pds.v4.z5.messages.ChatMessage;
import rs.raf.pds.v4.z5.messages.InfoMessage;
import rs.raf.pds.v4.z5.messages.KryoUtil;
import rs.raf.pds.v4.z5.messages.ListUsers;
import rs.raf.pds.v4.z5.messages.Login;
import rs.raf.pds.v4.z5.messages.WhoRequest;
import java.util.logging.Logger;

public class ChatServer implements Runnable {

	private volatile Thread thread = null;

	volatile boolean running = false;
	final Server server;
	final int portNumber;
	ConcurrentMap<String, Connection> userConnectionMap = new ConcurrentHashMap<String, Connection>();
	ConcurrentMap<Connection, String> connectionUserMap = new ConcurrentHashMap<Connection, String>();
	private final ConcurrentMap<String, ConcurrentMap<String, String>> chatRooms = new ConcurrentHashMap<>();
	private static final Logger logger = Logger.getLogger(ChatServer.class.getName());
	private final ConcurrentMap<String, List<ChatMessage>> roomMessages = new ConcurrentHashMap<>();
	private final ConcurrentMap<String, String> userRoomMap = new ConcurrentHashMap<>();
    private Map<String, Integer> userMessageCounter = new HashMap<>();


	public ChatServer(int portNumber) {
		this.server = new Server();
		this.portNumber = portNumber;
		KryoUtil.registerKryoClasses(server.getKryo());
		registerListener();
	}

	private void registerListener() {
		server.addListener(new Listener() {
			public void received(Connection connection, Object object) {
				if (object instanceof Login) {
					Login login = (Login) object;
					newUserLogged(login, connection);
					connection.sendTCP(new InfoMessage("Hello " + login.getUserName()));
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					return;
				}

				else if (object instanceof ChatMessage) {
					ChatMessage chatMessage = (ChatMessage) object;
					if ("ListRooms".equals(chatMessage.getTxt())) {
						sendChatRoomList(connection);
			        }
					else if (chatMessage.getTxt().startsWith("Ed ")) {
						System.out.println("Private room '" + chatMessage.getTxt());
					    String[] parts = chatMessage.getTxt().substring(3).split(" ", 2);
					    if (parts.length == 2) {
					        String originalMessage = parts[0];
					        String editedMessage = parts[1];
					        chatMessage.setTxt("Ed "+editedMessage);
					        
					        processEditedMessage(chatMessage, originalMessage);

					        //broadcastChatMessage(chatMessage, connection);
					    }else 
			    	        logger.warning("Length 2 doesn't exist.");
		

					}

				
					else if (userRoomMap.containsKey(chatMessage.getUser()) && !chatMessage.getTxt().contains("@")) {
			    	 String roomName = userRoomMap.get(chatMessage.getUser());
			    	    if (!chatRooms.containsKey(roomName)) {
			    	        logger.warning("Room '" + roomName + "' doesn't exist.");
			    	    } else {
			    	        List<ChatMessage> roomMessageList = roomMessages.get(roomName);

			    	        synchronized (roomMessageList) {
			    	            roomMessageList.add(new ChatMessage(chatMessage.getUser(), chatMessage.getTxt()));
			    	        }
			    	        broadcastChatMessageToRoom(chatMessage, roomName, connection);
			    	    }
				    }
				    else if (chatMessage.getTxt().startsWith("@") && chatMessage.getTxt().contains(" ")) {
						logger.info("@ sending @room command for room: ");

						String[] parts = chatMessage.getTxt().split(" ", 2);
						String recipient = parts[0].substring(1); 
						String messageText = parts[1]; 

						Connection recipientConnection = userConnectionMap.get(recipient);
						if (recipientConnection != null && recipientConnection.isConnected()) {
							recipientConnection.sendTCP(new ChatMessage(chatMessage.getUser(), messageText));
						} else {
							logger.warning("Person doesnt maybe exists(He is not connected/available).");

						}
					} else if (chatMessage.getTxt().startsWith("Create @")) {
						String roomName = chatMessage.getTxt().substring(8); 
						logger.info("Received Create @room command for room: " + roomName);

						if (!chatRooms.containsKey(roomName)) {
							ConcurrentMap<String, String> invitedUsers = new ConcurrentHashMap<>();
							invitedUsers.put(chatMessage.getUser(), chatMessage.getUser()); 
																							
						    List<ChatMessage> messages = Collections.synchronizedList(new ArrayList<>());
						    roomMessages.put(roomName, messages);
						    
							chatRooms.put(roomName, invitedUsers);
						//    userRoomMap.put(chatMessage.getUser(),roomName);
						    
							System.out.println("Private room '" + roomName + "' created and " + chatMessage.getUser()
									+ " invited.");
						} else {
							// System.out.println("Private room '" + roomName + "' already exists.");
							logger.warning("Room '" + roomName + "' already exists.");

						}
					}
					else if (chatMessage.getTxt().startsWith("Invite @")) {
					    String[] parts = chatMessage.getTxt().split(" ");
					    String roomName = parts[1].substring(1);
					    String invitedUser = parts[2].substring(1);
					    
					    if (chatRooms.containsKey(roomName)) {
					        ConcurrentMap<String, String> invitedUsers = chatRooms.get(roomName);

					        if (invitedUsers.containsKey(chatMessage.getUser())) {
					            invitedUsers.put(invitedUser, invitedUser);
					            System.out.println("User '" + invitedUser + "' invited to room '" + roomName + "'.");
					        } else {
					            System.out.println("You don't have the authority to invite to room '" + roomName + "'.");
					        }
					    } else {
					        System.out.println("Room '" + roomName + "' doesn't exist.");
					    }
					}
					
					 else if (chatMessage.getTxt().startsWith("Join @")) { 
						 String roomName = chatMessage.getTxt().substring(6); 

						    if (chatRooms.containsKey(roomName)) {
						        ConcurrentMap<String, String> invitedUsers = chatRooms.get(roomName);

						        if (invitedUsers.containsKey(chatMessage.getUser())) {
						        	
						            joinRoom(chatMessage.getUser(), roomName);
						            System.out.println(chatMessage.getUser() + " joined room: " + roomName);

						            List<ChatMessage> roomMessages = getLastRoomMessages(roomName);
						            sendLastRoomMessages(connection, roomMessages);
						        } else {
						            System.out.println(chatMessage.getUser() + " is not invited to room: " + roomName);
						        }
						    } else {
						        System.out.println("Room '" + roomName + "' doesn't exist.");
						    }
					 }
					 else if (chatMessage.getTxt().startsWith("Exit @")) { 
						 String roomName = chatMessage.getTxt().substring(6); // Extract room name from the command

						    if (chatRooms.containsKey(roomName)) {
						        ConcurrentMap<String, String> invitedUsers = chatRooms.get(roomName);

						        if (invitedUsers.containsKey(chatMessage.getUser())) {
						
						    	    userRoomMap.remove(chatMessage.getUser());

						            System.out.println(chatMessage.getUser() + " exited room: " + roomName);
						            broadcastExitMessage(chatMessage, roomName);

						        } else {
						            System.out.println(chatMessage.getUser() + " is not in the room: " + roomName);
						        }
						    } else {
						        System.out.println("Room '" + roomName + "' doesn't exist.");
						    }
					 }

					 else if (!isUserInAnyRoom(chatMessage.getUser())) {
							System.out.println(chatMessage.getUser() + ":damn:" + chatMessage.getTxt());

					     broadcastChatMessage(chatMessage, connection);
					 }
					 else if (chatMessage.getTxt().startsWith("GetMoreMessages @")) {
						    String roomName = chatMessage.getTxt().substring(17); 
						    logger.info("Received GetMoreMessages command for room: " + roomName);

						    List<ChatMessage> roomMessages = getNextRoomMessages(roomName);
						    
						    sendNextRoomMessages(connection, roomMessages);
						}


					else {
						logger.info("Broadcast command from server: ");

						System.out.println(chatMessage.getUser() + ":::" + chatMessage.getTxt());
						broadcastChatMessage(chatMessage, connection);
					}

				}

				if (object instanceof WhoRequest) {
					logger.info("WhoRequest command: ");

					ListUsers listUsers = new ListUsers(getAllUsers());
					connection.sendTCP(listUsers);
					return;
				}
//				if (chatRooms.containsKey("soba")) {
 //				    System.out.println("Chat room '@sobajedan' exists.");
//				} else {
//				    System.out.println("Chat room 'soba' does not exist.");
//				}

			}

			public void disconnected(Connection connection) {
				String user = connectionUserMap.get(connection);
				connectionUserMap.remove(connection);
				userConnectionMap.remove(user);
				showTextToAll(user + " has disconnected!", connection);
			}
		});
	}

	String[] getAllUsers() {
		String[] users = new String[userConnectionMap.size()];
		int i = 0;
		for (String user : userConnectionMap.keySet()) {
			users[i] = user;
			i++;
		}

		return users;
	}
	private boolean isUserInAnyRoom(String userName) {
	    return userRoomMap.containsKey(userName);
	}

	private void broadcastExitMessage(ChatMessage exitMessage, String roomName) {
	    for (Connection conn : userConnectionMap.values()) {
	        String userName = connectionUserMap.get(conn);

	        if (userRoomMap.containsKey(userName) && userRoomMap.get(userName).equals(roomName)) {
	            conn.sendTCP(exitMessage);
	        }
	    }
	}
	private void processEditedMessage(ChatMessage chatMessage, String originalMessage) {
	    String userName = chatMessage.getUser();
	    String roomName = userRoomMap.get(userName);
	    String edited = chatMessage.getTxt();


	    if (roomName != null && roomMessages.containsKey(roomName)) {
	        List<ChatMessage> roomMessageList = roomMessages.get(roomName);

	        synchronized (roomMessageList) {
	        	
	            for (Iterator<ChatMessage> iterator = roomMessageList.iterator(); iterator.hasNext();) {
	                ChatMessage message = iterator.next();
	                if (message.getUser().equals(userName) && message.getTxt().equals(originalMessage)) {
	                	message.setTxt(edited);
	                    //iterator.remove(); 
	                    break;
	                }
	            }
	        }

	        broadcastChatMessageToRoom(chatMessage, roomName, null);
	    }
	}

	private void broadcastChatMessageToRoom(ChatMessage message, String roomName, Connection exception) {
	    for (Connection conn : userConnectionMap.values()) {
	        String userName = connectionUserMap.get(conn);
	        if (userRoomMap.containsKey(userName) && userRoomMap.get(userName).equals(roomName)) {
	          //  if (conn != exception) {
	                conn.sendTCP(message);
	         //   }
	        }
	    }
	}

//	private void broadcastChatMessageToRoom(ChatMessage message, String roomName, Connection senderConnection) {
//	    for (Connection conn : userConnectionMap.values()) {
//	        String userName = connectionUserMap.get(conn);
//	        if (userRoomMap.containsKey(userName) && userRoomMap.get(userName).equals(roomName)) {
//	            //if (!conn.equals(senderConnection)) {
//	                conn.sendTCP(message);
//	            //}
//	        }
//	    }
//	}
	private List<ChatMessage> getNextRoomMessages(String roomName) {
	    List<ChatMessage> messages = roomMessages.getOrDefault(roomName, new ArrayList<>());
	    int startIndex = userMessageCounter.getOrDefault(roomName, 0);
	    int endIndex = Math.min(startIndex + 5, messages.size());
	    
	    userMessageCounter.put(roomName, endIndex);
	    
     return messages.subList(startIndex, endIndex);
	}

	private void sendNextRoomMessages(Connection connection, List<ChatMessage> roomMessages) {
	    for (ChatMessage message : roomMessages) {
	        connection.sendTCP(message);
	    }
	}

	private List<ChatMessage> getLastRoomMessages(String roomName) {
	    List<ChatMessage> messages = roomMessages.getOrDefault(roomName, new ArrayList<>());
	    int totalMessages = messages.size();
	    int startIndex = Math.max(0, totalMessages - 5); 

	    return messages.subList(startIndex, totalMessages);
	}

	private void sendLastRoomMessages(Connection connection, List<ChatMessage> roomMessages) {
	    for (ChatMessage message : roomMessages) {
	        connection.sendTCP(message);
	    }
	}
	private void joinRoom(String userName, String roomName) {
	    userRoomMap.put(userName, roomName);
	}

	void newUserLogged(Login loginMessage, Connection conn) {
		userConnectionMap.put(loginMessage.getUserName(), conn);
		connectionUserMap.put(conn, loginMessage.getUserName());
		showTextToAll("User " + loginMessage.getUserName() + " has connected!", conn);

	    sendChatRoomList(conn);
	}
	private void sendChatRoomList(Connection conn) {
	    String[] roomNames = chatRooms.keySet().toArray(new String[0]);
	    ListUsers listRooms = new ListUsers(roomNames);
	    conn.sendTCP(listRooms);
	}



	private void broadcastChatMessage(ChatMessage message, Connection exception) {
	    for (Connection conn : userConnectionMap.values()) {
	        String userName = connectionUserMap.get(conn);
	        
	        if (!isUserInAnyRoom(userName)) {
	            if (conn.isConnected() && conn != exception) {
	                conn.sendTCP(message);
	            }
	        }
	    }
	}

	private void showTextToAll(String txt, Connection exception) {
		System.out.println(txt);
		for (Connection conn : userConnectionMap.values()) {
			if (conn.isConnected() && conn != exception)
				conn.sendTCP(new InfoMessage(txt));
		}
	}

	public void start() throws IOException {
		server.start();
		server.bind(portNumber);

		if (thread == null) {
			thread = new Thread(this);
			thread.start();
		}
	}

	public void stop() {
		Thread stopThread = thread;
		thread = null;
		running = false;
		if (stopThread != null)
			stopThread.interrupt();
	}

	@Override
	public void run() {
		running = true;

		while (running) {
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {

		if (args.length != 1) {
			System.err.println("Usage: java -jar chatServer.jar <port number>");
			System.out.println("Recommended port number is 54555");
			System.exit(1);
		}

		int portNumber = Integer.parseInt(args[0]);
		try {
			ChatServer chatServer = new ChatServer(portNumber);
			chatServer.start();

			chatServer.thread.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
