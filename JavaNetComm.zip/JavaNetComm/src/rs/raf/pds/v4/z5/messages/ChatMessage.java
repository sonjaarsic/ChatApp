package rs.raf.pds.v4.z5.messages;

public class ChatMessage {
	String user;
	String txt;
    String originalMessage;  

	protected ChatMessage() {
		
	}
	public ChatMessage(String user, String txt) {
		this.user = user;
		this.txt = txt;
	}
	 public ChatMessage(String user, String originalMessage, String editedMessage) {
	        this.user = user;
	        this.originalMessage = originalMessage;
	        this.txt = "Ed " + editedMessage;
	    }

	public String getUser() {
		return user;
	}

	public String getTxt() {
		return txt;
	}
	public String getOrig() {
		return originalMessage;
	}
	public void setTxt(String txt) {
		this.txt = txt;
	}
	public void setOrig(String originalMessage) {
		this.originalMessage = originalMessage;
	}
	
}
