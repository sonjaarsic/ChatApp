package rs.raf.pds.v4.z5;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;

public class ChatClientUI extends Application {

    private int clientCount = 0;

    @Override
    public void start(Stage primaryStage) {
        Button createClientButton = new Button("Create New Client");
        VBox root = new VBox(createClientButton);

        createClientButton.setOnAction(e -> createNewClient());

        Scene scene = new Scene(root, 300, 200);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Chat Client Manager");
        primaryStage.show();
    }

    private void createNewClient() {
        Stage clientStage = new Stage();

        TextArea chatArea = new TextArea();
        TextField inputField = new TextField();
        Button sendButton = new Button("Send");

        VBox clientRoot = new VBox(chatArea, inputField, sendButton);

        ChatClient chatClient = new ChatClient("localhost", 9000, "User" + (++clientCount));

        chatArea.setOnMouseClicked(event -> {
            if (event.getButton() == MouseButton.SECONDARY) {
                String selectedText = chatArea.getSelectedText();
                if (selectedText != null && !selectedText.isEmpty()) {
                    inputField.setText(selectedText);
                }
            }
        });

        sendButton.setOnAction(e -> {
            String message = inputField.getText().trim();
            if (!message.isEmpty()) {
                if (chatArea.getSelectedText() != null && !chatArea.getSelectedText().isEmpty()) {
                    String originalMessage = chatArea.getSelectedText();

                    chatClient.sendMessage("Ed " + originalMessage+" "+message);
                    chatArea.setText(chatArea.getText().replace(originalMessage, inputField.getText()+" Ed by you"));

                } else {
                    chatClient.sendMessage(message);
                }
                inputField.clear();
            }
        });

        try {
            chatClient.start();
            chatClient.setMessageListener(message -> {
                if (message.contains("Ed")) {
                    chatArea.appendText(message + " Ed" + "\n");

//                    String[] parts = message.split(" ", 3);
//                    String originalMessage = parts[1];
//                    String editedMessage = parts[2];
//
  //                   chatArea.setText(chatArea.getText().replace(originalMessage, editedMessage));
                } else {
                    chatArea.appendText(message + "\n");
                }
            });
        } catch (IOException ex) {
            ex.printStackTrace();
            System.err.println("Error connecting to the server: " + ex.getMessage());
        }
        Scene clientScene = new Scene(clientRoot, 400, 300);
        clientStage.setScene(clientScene);
        clientStage.setTitle("Chat Client - " + chatClient.getUserName());

        clientStage.show(); 
    }

    public static void main(String[] args) {
        launch(args);
    }
}
