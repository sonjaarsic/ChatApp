package rs.raf.pds.v4.z5.messages;
import java.io.Serializable;

public class RoomHistoryChat implements Serializable  {

	    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		private String roomName;
	    private ChatMessage[] lastFiveMessages;

	    public RoomHistoryChat(String roomName, ChatMessage[] lastFiveMessages) {
	        this.roomName = roomName;
	        this.lastFiveMessages = lastFiveMessages;
	    }

	    public String getRoomName() {
	        return roomName;
	    }

	    public ChatMessage[] getLastFiveMessages() {
	        return lastFiveMessages;
	    }
	
}
