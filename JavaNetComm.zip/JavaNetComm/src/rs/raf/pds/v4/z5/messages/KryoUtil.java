package rs.raf.pds.v4.z5.messages;
import java.util.logging.Logger;

import com.esotericsoftware.kryo.Kryo;

public class KryoUtil {
    private static final Logger logger = Logger.getLogger(KryoUtil.class.getName());

	public static void registerKryoClasses(Kryo kryo) {
        logger.info("Registering classes for Kryo serialization.");

		kryo.register(String.class);
		kryo.register(String[].class);
		kryo.register(Login.class);
		kryo.register(ChatMessage.class);
		kryo.register(WhoRequest.class);
		kryo.register(ListUsers.class);
		kryo.register(InfoMessage.class);
        logger.info("Registration completed.");

	}
}
